-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 19 déc. 2021 à 03:38
-- Version du serveur : 10.4.21-MariaDB
-- Version de PHP : 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestion_clinique`
--

-- --------------------------------------------------------

--
-- Structure de la table `consultation`
--

CREATE TABLE `consultation` (
  `idConsultation` int(11) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `heure` varchar(255) NOT NULL,
  `constantesPrises` varchar(255) NOT NULL,
  `idMedecin` int(11) NOT NULL,
  `prenomMedecin` varchar(255) NOT NULL,
  `nomMedecin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `dossiermedical`
--

CREATE TABLE `dossiermedical` (
  `idDossierMedical` int(11) NOT NULL,
  `nciPatient` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `ordonnance`
--

CREATE TABLE `ordonnance` (
  `idOrdonnance` int(11) NOT NULL,
  `nomMedicament` varchar(255) NOT NULL,
  `posologie` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

CREATE TABLE `prestation` (
  `idPrestation` int(11) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `nomPrestation` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `rendezvous`
--

CREATE TABLE `rendezvous` (
  `idRV` int(11) NOT NULL,
  `dateDemande` date NOT NULL DEFAULT current_timestamp(),
  `heureDemande` time NOT NULL DEFAULT current_timestamp(),
  `dateRv` varchar(255) DEFAULT 'Vide',
  `heureRv` varchar(255) DEFAULT 'Vide',
  `idPatient` int(25) NOT NULL,
  `prenomPatient` varchar(255) NOT NULL,
  `nomPatient` varchar(255) NOT NULL,
  `typeDeRv` varchar(255) DEFAULT NULL,
  `objetRv` varchar(255) DEFAULT NULL,
  `idMedecin` int(11) DEFAULT NULL,
  `statut` varchar(255) NOT NULL DEFAULT 'En attente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `rendezvous`
--

INSERT INTO `rendezvous` (`idRV`, `dateDemande`, `heureDemande`, `dateRv`, `heureRv`, `idPatient`, `prenomPatient`, `nomPatient`, `typeDeRv`, `objetRv`, `idMedecin`, `statut`) VALUES
(2, '2021-12-18', '22:29:29', '2021-12-19', '10:31', 6, 'Moussa', 'Sow', 'Consultation', 'Chirurgien', 2, 'Validé');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nci` int(11) DEFAULT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `typeMedecin` varchar(255) DEFAULT NULL,
  `passeMedicaux` varchar(255) DEFAULT NULL,
  `jourDeTravail` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `nci`, `nom`, `prenom`, `login`, `password`, `role`, `typeMedecin`, `passeMedicaux`, `jourDeTravail`) VALUES
(1, NULL, 'Diop', 'Mbene', 'mbene@gmail.com', 'mbene123', 'ROLE_RP', NULL, NULL, NULL),
(2, NULL, 'Diop', 'Amina', 'amina@gmail.com', 'amina123', 'ROLE_MEDECIN', 'Pediatre', NULL, 'Lundi 8H - 12H\r\nMardi 8H - 12H'),
(3, NULL, 'Sy', 'Aissatou', 'aissatou@gmail.com', 'aissatou123', 'ROLE_MEDECIN', 'Ophtalmologue', NULL, 'Mardi 8H - 17H\r\nJeudi 8H - 17H'),
(4, NULL, 'Dia', 'Lamine', 'lamine@gmail.com', 'lamine123', 'ROLE_MEDECIN', 'Dentiste', NULL, 'Lundi 8H - 17H\r\nMardi 8H - 17H'),
(5, NULL, 'Ndiaye', 'Maman', 'maman@gmail.com', 'maman123', 'ROLE_SECRETAIRE', NULL, NULL, NULL),
(6, 12345, 'Sow', 'Moussa', 'moussa@gmail.com', 'moussa123', 'ROLE_PATIENT', NULL, 'DIABETE', NULL),
(7, 17282, 'Sall', 'Tafus', 'tafus@gmail.com', 'tafus123', 'ROLE_PATIENT', NULL, 'HEPATITE', NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `consultation`
--
ALTER TABLE `consultation`
  ADD PRIMARY KEY (`idConsultation`);

--
-- Index pour la table `dossiermedical`
--
ALTER TABLE `dossiermedical`
  ADD PRIMARY KEY (`idDossierMedical`);

--
-- Index pour la table `ordonnance`
--
ALTER TABLE `ordonnance`
  ADD PRIMARY KEY (`idOrdonnance`);

--
-- Index pour la table `prestation`
--
ALTER TABLE `prestation`
  ADD PRIMARY KEY (`idPrestation`);

--
-- Index pour la table `rendezvous`
--
ALTER TABLE `rendezvous`
  ADD PRIMARY KEY (`idRV`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `consultation`
--
ALTER TABLE `consultation`
  MODIFY `idConsultation` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `dossiermedical`
--
ALTER TABLE `dossiermedical`
  MODIFY `idDossierMedical` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `ordonnance`
--
ALTER TABLE `ordonnance`
  MODIFY `idOrdonnance` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `prestation`
--
ALTER TABLE `prestation`
  MODIFY `idPrestation` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `rendezvous`
--
ALTER TABLE `rendezvous`
  MODIFY `idRV` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
