/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author ASUS
 */
public class Ordonnance {
    
    private int id;
    private String nomMedicament;
    private String posologie;
    
    //Attribut Navigationnel
    private Patient patient;

    //Constructeur
    public Ordonnance() {
    }

    public Ordonnance(int id, String nomMedicament, String posologie) {
        this.id = id;
        this.nomMedicament = nomMedicament;
        this.posologie = posologie;
    }

    public Ordonnance(String nomMedicament, String posologie) {
        this.nomMedicament = nomMedicament;
        this.posologie = posologie;
    }

    //Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomMedicament() {
        return nomMedicament;
    }

    public void setNomMedicament(String nomMedicament) {
        this.nomMedicament = nomMedicament;
    }

    public String getPosologie() {
        return posologie;
    }

    public void setPosologie(String posologie) {
        this.posologie = posologie;
    }
    
    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }
    
    
}
