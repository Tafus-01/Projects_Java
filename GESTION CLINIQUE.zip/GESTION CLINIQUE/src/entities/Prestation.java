/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author ASUS
 */
public class Prestation{
    
    private String nomPrestation;
    
    //Attribut Navigationnel
    private DossierMedical dossiermedical;
    private ResponsablePrestation responsableprestaion;

    public Prestation() { 
    }

    public String getNomPrestation() {
        return nomPrestation;
    }

    public void setNomPrestation(String nomPrestation) {
        this.nomPrestation = nomPrestation;
    }

    public DossierMedical getDossiermedical() {
        return dossiermedical;
    }

    public void setDossiermedical(DossierMedical dossiermedical) {
        this.dossiermedical = dossiermedical;
    }

    public ResponsablePrestation getResponsableprestaion() {
        return responsableprestaion;
    }

    public void setResponsableprestaion(ResponsablePrestation responsableprestaion) {
        this.responsableprestaion = responsableprestaion;
    }
    
    
}
