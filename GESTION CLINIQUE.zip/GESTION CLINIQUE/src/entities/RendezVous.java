/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author ASUS
 */
public class RendezVous {

    private int id;
    private String date;
    private String dateRv;
    private String heureRv;
    private String typeDeRv;
    private String objetRv;
    private String statut;
    private String prenomPatient;
    private String nomPatient;

    //Attribut Navigationnel
    private Patient patient;
    private Secretaire secretaire;

    public RendezVous() {
    }

    public RendezVous(int id, String date, String dateRv, String heureRv, String prenomPatient, String nomPatient, String typeDeRv, String objetRv, String statut) {
        this.id = id;
        this.date = date;
        this.dateRv = dateRv;
        this.heureRv = heureRv;
        this.prenomPatient = prenomPatient;
        this.nomPatient = nomPatient;
        this.typeDeRv = typeDeRv;
        this.objetRv = objetRv;
        this.statut = statut;
        
    }

    //Constructeur ValideRv
    public RendezVous(String dateRv, String statut) {
        this.dateRv = dateRv;
        this.statut = statut;
    }

    //Constructeur insertRv
    public RendezVous(int id, String prenomPatient, String nomPatient, String typeDeRv, String objetRv) {
        this.id = id;
        this.typeDeRv = typeDeRv;
        this.objetRv = objetRv;
        this.prenomPatient = prenomPatient;
        this.nomPatient = nomPatient;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDateRv() {
        return dateRv;
    }

    public void setDateRv(String dateRv) {
        this.dateRv = dateRv;
    }

    public String getTypeDeRv() {
        return typeDeRv;
    }

    public void setTypeDeRv(String typeDeRv) {
        this.typeDeRv = typeDeRv;
    }

    public String getObjetRv() {
        return objetRv;
    }

    public void setObjetRv(String objetRv) {
        this.objetRv = objetRv;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Secretaire getSecretaire() {
        return secretaire;
    }

    public void setSecretaire(Secretaire secretaire) {
        this.secretaire = secretaire;
    }

    public String getPrenomPatient() {
        return prenomPatient;
    }

    public void setPrenomPatient(String prenomPatient) {
        this.prenomPatient = prenomPatient;
    }

    public String getNomPatient() {
        return nomPatient;
    }

    public void setNomPatient(String nomPatient) {
        this.nomPatient = nomPatient;
    }

    public String getHeureRv() {
        return heureRv;
    }

    public void setHeureRv(String heureRv) {
        this.heureRv = heureRv;
    }

    

}
