/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author ASUS
 */
public class Medecin extends User {

    private String typeMedecin;
    private String workDay;
    private final String ROLE = "ROLE_MEDECIN";
    //Attribut Navigationnel
    private List<Consultation> consultation;

    //Constructeur
    public Medecin() {

    }

    public Medecin(int id, String nom, String prenom, String login, String password, String typeMedecin, String workDay) {
        super(id, nom, prenom, login, password);
        this.typeMedecin = typeMedecin;
        this.workDay = workDay;
        this.role = ROLE;
    }

    public Medecin(String typeMedecin, String workDay, String nom, String prenom, String login, String password) {
        super(nom, prenom, login, password);
        this.typeMedecin = typeMedecin;
        this.workDay = workDay;
         this.role = ROLE;
    }

    public String getTypeMedecin() {
        return typeMedecin;
    }

    public void setTypeMedecin(String typeMedecin) {
        this.typeMedecin = typeMedecin;
    }

    public String getWorkDay() {
        return workDay;
    }

    public void setWorkDay(String workDay) {
        this.workDay = workDay;
    }

   

    public List<Consultation> getConsultation() {
        return consultation;
    }

    public void setConsultation(List<Consultation> consultation) {
        this.consultation = consultation;
    }

}
