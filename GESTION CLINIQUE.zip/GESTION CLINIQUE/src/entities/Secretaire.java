/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author ASUS
 */
public class Secretaire extends User{
    
    private final String ROLE="ROLE_SECRETAIRE";

    //Attribut Navigationnel
    private List<RendezVous> rendezvous;
    
    
    
    //Constructeur
    public Secretaire() {
        this.role = ROLE;
    }

    public Secretaire(int id, String nom, String prenom, String login, String password) {
        super(id, nom, prenom, login, password);
        this.role = ROLE;
    }

    public Secretaire(String nom, String prenom, String login, String password) {
        super(nom, prenom, login, password);
        this.role = ROLE;
    }

   
 

    public List<RendezVous> getRendezvous() {
        return rendezvous;
    }

    public void setRendezvous(List<RendezVous> rendezvous) {
        this.rendezvous = rendezvous;
    }
    
    
}
