/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author ASUS
 */
public class Patient extends User{
    
    private String passeMedicaux;
    private String nci;
    private final String ROLE="ROLE_PATIENT";
    
    //Attribut Navigationnel
    private List<RendezVous> rendezvous;
    private List<Ordonnance> ordonnance;
    private DossierMedical dossiermedical;

    //Constructeur
    public Patient() {
        this.role = ROLE;
    }

    public Patient(String passeMedicaux, String nci, int id, String nom, String prenom, String login, String password) {
        super(id, nom, prenom, login, password);
        this.passeMedicaux = passeMedicaux;
        this.role = ROLE;
        this.nci = nci;
    }

    public Patient(String passeMedicaux, String nom, String prenom, String login, String password, String nci) {
        super(nom, prenom, login, password);
        this.passeMedicaux = passeMedicaux;
        this.nci = nci;
        this.role = ROLE;
    }

    public Patient(String nci) {
        this.nci = nci;
    }


    public String getPasseMedicaux() {
        return passeMedicaux;
    }

    public void setPasseMedicaux(String passeMedicaux) {
        this.passeMedicaux = passeMedicaux;
    }

    public String getNci() {
        return nci;
    }

    public void setNci(String nci) {
        this.nci = nci;
    }
    

    public List<RendezVous> getRendezvous() {
        return rendezvous;
    }

    public void setRendezvous(List<RendezVous> rendezvous) {
        this.rendezvous = rendezvous;
    }
   
    public List<Ordonnance> getOrdonnance() {
        return ordonnance;
    }

    public void setOrdonnance(List<Ordonnance> ordonnance) {
        this.ordonnance = ordonnance;
    }
    
    public DossierMedical getDossiermedical() {
        return dossiermedical;
    }

    public void setDossiermedical(DossierMedical dossiermedical) {
        this.dossiermedical = dossiermedical;
    }


    

    
    
    
}
