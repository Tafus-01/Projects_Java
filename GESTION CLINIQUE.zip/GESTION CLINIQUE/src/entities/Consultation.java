/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author ASUS
 */
public class Consultation extends RendezVous {

    private int tension;
    private int temperature;
    private String typeMedecin;
    private int idMedecin;

   
    private int idPatient;

    //Attribut Navigationnel
    private DossierMedical dossiermedical;
    private Medecin medecin;

    public Consultation() {
    }

    public Consultation(int tension, int temperature, String typeMedecin, int idMedecin, int idPatient, DossierMedical dossiermedical, Medecin medecin, int id, String date, String dateRv, String heureRv, String prenomPatient, String nomPatient, String typeDeRv, String objetRv, String statut) {
        super(id, date, dateRv, heureRv, prenomPatient, nomPatient, typeDeRv, objetRv, statut);
        this.tension = tension;
        this.temperature = temperature;
        this.typeMedecin = typeMedecin;
        this.idMedecin = idMedecin;
        this.idPatient = idPatient;
        this.dossiermedical = dossiermedical;
        this.medecin = medecin;
    }
    
    
 
    public Consultation(int tension, int temperature, String typeMedecin) {
        this.tension = tension;
        this.temperature = temperature;
        this.typeMedecin = typeMedecin;
    }

    public int getTension() {
        return tension;
    }

    public void setTension(int tension) {
        this.tension = tension;
    }

    public int getTemperature() {
        return temperature;
    }

    public void setTemperature(int temperature) {
        this.temperature = temperature;
    }

    
    public String getTypeMedecin() {
        return typeMedecin;
    }

    public void settypeMedecin(String typeMedecin) {
        this.typeMedecin = typeMedecin;
    }

    public DossierMedical getDossiermedical() {
        return dossiermedical;
    }

    public void setDossiermedical(DossierMedical dossiermedical) {
        this.dossiermedical = dossiermedical;
    }

    public Medecin getMedecin() {
        return medecin;
    }

    public void setMedecin(Medecin medecin) {
        this.medecin = medecin;
    }

     public int getIdMedecin() {
        return idMedecin;
    }

    public void setIdMedecin(int idMedecin) {
        this.idMedecin = idMedecin;
    }

    public int getIdPatient() {
        return idPatient;
    }

    public void setIdPatient(int idPatient) {
        this.idPatient = idPatient;
    }
}
