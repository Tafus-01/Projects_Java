/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Consultation;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class ConsultationDao implements IDao<Consultation> {

    private final Database dataBase = new Database();

    private final String SQL_INSERT_CONSULTATION = "INSERT INTO consultation "
            + " (date, heure, tension, temperature, idMedecin, idPatient)"
            + " VALUES (?, ?, ?, ?, ?, ?)";

    @Override
    public int insert(Consultation consultation) {
        int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT_CONSULTATION);
            dataBase.getPs().setString(1, consultation.getDate());
            dataBase.getPs().setString(2, consultation.getHeureRv());
            dataBase.getPs().setInt(3, consultation.getTension());
            dataBase.getPs().setInt(4, consultation.getTemperature());
            dataBase.getPs().setInt(5, consultation.getIdMedecin());
            dataBase.getPs().setInt(6, consultation.getIdPatient());
            dataBase.executeUpdate(SQL_INSERT_CONSULTATION);
            ResultSet rs = dataBase.getPs().getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PatientDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            dataBase.closeConnexion();
        }
        return id;
    }

    @Override
    public int update(Consultation ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Consultation> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Consultation findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
