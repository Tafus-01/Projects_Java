/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.RendezVous;
import entities.Secretaire;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class SecretaireDao implements IDao<Secretaire> {

    private final Database dataBase = new Database();

    private final String SQL_VALIDE_CONSULTATION = "UPDATE rendezvous "
            + "SET dateRv = ?, heureRv = ?, idMedecin = ?, statut = 'Validé' "
            + " WHERE statut = 'En attente' AND idRV = ?";

    @Override
    public int insert(Secretaire ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int update(Secretaire ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Secretaire> findAll() {
        return null;
        
    }

    @Override
    public Secretaire findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int valideRendezVous(RendezVous rendezvous, int idMedecin) {
        int nbrLigne;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_VALIDE_CONSULTATION);
        try {
            dataBase.getPs().setString(1, rendezvous.getDateRv());
            dataBase.getPs().setString(2, rendezvous.getHeureRv());
            dataBase.getPs().setInt(3, idMedecin);
            dataBase.getPs().setInt(4, rendezvous.getId());
        } catch (SQLException ex) {
            Logger.getLogger(SecretaireDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        nbrLigne = dataBase.executeUpdate(SQL_VALIDE_CONSULTATION);
        dataBase.closeConnexion();
        return nbrLigne;
    }

}
