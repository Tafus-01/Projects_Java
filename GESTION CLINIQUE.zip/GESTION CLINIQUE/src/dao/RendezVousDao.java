/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.RendezVous;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import views.ConnexionController;

/**
 *
 * @author ASUS
 */
public class RendezVousDao implements IDao<RendezVous> {

    private final Database dataBase = new Database();

    private final String SQL_ALL_CONSULTATION_BY_PATIENT = " SELECT * FROM rendezvous "
            + " WHERE idPatient = ? AND typeDeRv = 'Consultation' ";

    private final String SQL_ALL_PRESTATION_BY_PATIENT = " SELECT * FROM rendezvous"
            + " WHERE idPatient = ? AND typeDeRv = 'Prestation' ";

    private final String SQL_ALL_RENDEZVOUS_VALIDE = " SELECT * FROM user p, rendezvous r "
            + " WHERE p.id = r.idMedecin AND p.id = ? "
            + " AND r.statut = 'validé' AND r.typeDeRv = 'Consultation'";

    private final String SQL_ALL_CONSULTATION = " SELECT * FROM rendezvous "
            + " WHERE typeDeRv = 'Consultation' ";

    private final String SQL_ALL_PRESTATION = " SELECT * FROM rendezvous"
            + " WHERE typeDeRv = 'Prestation' ";

    private final String SQL_INSERT = "INSERT INTO rendezvous "
            + " (idPatient, prenomPatient, nomPatient, typeDeRv, objetRv)"
            + " VALUES (?, ?, ?, ?, ?)";

    private final String SQL_DELETE = "DELETE From rendezvous"
            + " WHERE idRV = ?";

    @Override
    public int insert(RendezVous rendezvous) {
        int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
            dataBase.getPs().setInt(1, rendezvous.getId());
            dataBase.getPs().setString(2, rendezvous.getPrenomPatient());
            dataBase.getPs().setString(3, rendezvous.getNomPatient());
            dataBase.getPs().setString(4, rendezvous.getTypeDeRv());
            dataBase.getPs().setString(5, rendezvous.getObjetRv());
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs = dataBase.getPs().getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PatientDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            dataBase.closeConnexion();
        }
        return id;
    }

    @Override
    public int update(RendezVous ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        int nbrLigne = 0;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_DELETE);
        try {
            dataBase.getPs().setInt(1, id);
            nbrLigne = dataBase.executeUpdate(SQL_DELETE);
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return nbrLigne;
    }

    @Override
    public RendezVous findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RendezVous> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    //All Consultation by Patient
    public List<RendezVous> findAllConsultationByPatient(int id) {
        RendezVous rv;
        List<RendezVous> consultations = new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_CONSULTATION_BY_PATIENT);
        try {
            dataBase.getPs().setInt(1, ConnexionController.getCtrl().getUser().getId());
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        ResultSet rs = dataBase.executeSelect(SQL_ALL_CONSULTATION_BY_PATIENT);
        try {
            while (rs.next()) {
                rv = new RendezVous(
                        rs.getInt("idRv"),
                        rs.getString("dateDemande"),
                        rs.getString("dateRv"),
                        rs.getString("heureRv"),
                        rs.getString("prenomPatient"),
                        rs.getString("nomPatient"),
                        rs.getString("typeDeRv"),
                        rs.getString("objetRv"),
                        rs.getString("statut")
                );
                consultations.add(rv);
            }
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return consultations;
    }

    //All Prestation by Patient
    public List<RendezVous> findAllPrestationByPatient(int id) {
        RendezVous rv;
        List<RendezVous> prestations = new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_PRESTATION_BY_PATIENT);
        try {
            dataBase.getPs().setInt(1, ConnexionController.getCtrl().getUser().getId());
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        ResultSet rs = dataBase.executeSelect(SQL_ALL_PRESTATION_BY_PATIENT);
        try {
            while (rs.next()) {
                rv = new RendezVous(
                        rs.getInt("idRv"),
                        rs.getString("dateDemande"),
                        rs.getString("dateRv"),
                        rs.getString("heureRv"),
                        rs.getString("prenomPatient"),
                        rs.getString("nomPatient"),
                        rs.getString("typeDeRv"),
                        rs.getString("objetRv"),
                        rs.getString("statut")
                );
                prestations.add(rv);
            }
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return prestations;
    }

    //All Consultation Secretaire
    public List<RendezVous> findAllConsultation() {
        RendezVous rv;
        List<RendezVous> consultations = new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_CONSULTATION);
        ResultSet rs = dataBase.executeSelect(SQL_ALL_CONSULTATION);
        try {
            while (rs.next()) {
                rv = new RendezVous(
                        rs.getInt("idRv"),
                        rs.getString("dateDemande"),
                        rs.getString("dateRv"),
                        rs.getString("heureRv"),
                        rs.getString("prenomPatient"),
                        rs.getString("nomPatient"),
                        rs.getString("typeDeRv"),
                        rs.getString("objetRv"),
                        rs.getString("statut")
                );
                consultations.add(rv);
            }
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return consultations;
    }

    //All Prestation Secretaire
    public List<RendezVous> findAllPrestation() {
        RendezVous rv;
        List<RendezVous> prestations = new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_PRESTATION);
        ResultSet rs = dataBase.executeSelect(SQL_ALL_PRESTATION);
        try {
            while (rs.next()) {
                rv = new RendezVous(
                        rs.getInt("idRv"),
                        rs.getString("dateDemande"),
                        rs.getString("dateRv"),
                        rs.getString("heureRv"),
                        rs.getString("prenomPatient"),
                        rs.getString("nomPatient"),
                        rs.getString("typeDeRv"),
                        rs.getString("objetRv"),
                        rs.getString("statut")
                );
                prestations.add(rv);
            }
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return prestations;
    }

    //All RV valide Medecin
    public List<RendezVous> findAllRendezVousValide(int id) {
        RendezVous rv;
        List<RendezVous> rendezvous = new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_RENDEZVOUS_VALIDE);
        try {
            dataBase.getPs().setInt(1, ConnexionController.getCtrl().getUser().getId());
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        ResultSet rs = dataBase.executeSelect(SQL_ALL_RENDEZVOUS_VALIDE);
        try {
            while (rs.next()) {
                rv = new RendezVous(
                        rs.getInt("idPatient"),
                        rs.getString("dateDemande"),
                        rs.getString("dateRv"),
                        rs.getString("heureRv"),
                        rs.getString("prenomPatient"),
                        rs.getString("nomPatient"),
                        rs.getString("typeDeRv"),
                        rs.getString("objetRv"),
                        rs.getString("statut")
                );
                rendezvous.add(rv);
            }
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return rendezvous;
    }

}
