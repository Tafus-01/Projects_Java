/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Prestation;
import entities.RendezVous;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import views.ConnexionController;

/**
 *
 * @author ASUS
 */
public class PrestationDao implements IDao<Prestation>{

    private final String SQL_ALL_PRESTATION_VALIDE = " SELECT * FROM user p, rendezvous r "
            + " WHERE p.id = r.idMedecin AND p.id = ? "
            + " AND r.statut = 'validé' AND r.typeDeRv = 'Prestation'";
    
    private final Database dataBase = new Database();
    @Override
    public int insert(Prestation ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int update(Prestation ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Prestation> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Prestation findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<RendezVous> findAllRendezVousValide(int id) {
        RendezVous rv;
        List<RendezVous> rendezvous = new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_PRESTATION_VALIDE);
        try {
            dataBase.getPs().setInt(1, ConnexionController.getCtrl().getUser().getId());
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        ResultSet rs = dataBase.executeSelect(SQL_ALL_PRESTATION_VALIDE);
        try {
            while (rs.next()) {
                rv = new RendezVous(
                        rs.getInt("idPatient"),
                        rs.getString("dateDemande"),
                        rs.getString("dateRv"),
                        rs.getString("heureRv"),
                        rs.getString("prenomPatient"),
                        rs.getString("nomPatient"),
                        rs.getString("typeDeRv"),
                        rs.getString("objetRv"),
                        rs.getString("statut")
                );
                rendezvous.add(rv);
            }
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return rendezvous;
    }
    
}
