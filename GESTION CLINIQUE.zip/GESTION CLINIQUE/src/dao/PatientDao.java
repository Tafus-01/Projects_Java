/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Patient;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class PatientDao implements IDao<Patient> {

    private final Database dataBase = new Database();

    private final String SQL_INSERT = "INSERT INTO user "
            + " (nci, nom, prenom, login, password, role, passeMedicaux) "
            + " VALUES (?, ?, ?, ?, ?, 'ROLE_PATIENT', ?)";

    private final String SQL_ALL_PRESTATION = " SELECT * FROM rendezvous"
            + " WHERE id = ? AND typeDeRv 'Prestation' ";

    @Override
    public int insert(Patient patient) {

        int id = 0;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_INSERT);

        try {
            dataBase.getPs().setString(1, patient.getNci());
            dataBase.getPs().setString(2, patient.getNom());
            dataBase.getPs().setString(3, patient.getPrenom());
            dataBase.getPs().setString(4, patient.getLogin());
            dataBase.getPs().setString(5, patient.getPassword());
            dataBase.getPs().setString(6, patient.getPasseMedicaux());
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs = dataBase.getPs().getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PatientDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            dataBase.closeConnexion();
        }
        return id;

    }

    @Override
    public int update(Patient ogj
    ) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id
    ) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Patient> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Patient findById(int id
    ) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /*
    public Patient inscription(String login, String password, String role, String nomComplet){
        
        return new Patient();
        
    }
     */
}
