/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utils;

import javafx.scene.control.ComboBox;

/**
 *
 * @author ASUS
 */
public class ViewService {

    public static void loadComboBoxTypeRv(ComboBox<String> cboTypeRv) {
        cboTypeRv.getItems().add("Consultation");
        cboTypeRv.getItems().add("Prestation");
        //cboTypeRv.getSelectionModel().selectFirst();

    }

    public static void loadComboBoxObjetConsultation(ComboBox<String> cboObjetRv) {
        //cboObjetRv.setItems(null);
        cboObjetRv.getItems().clear();
        cboObjetRv.getItems().add("Dentiste");
        cboObjetRv.getItems().add("Ophtalmologue");
        cboObjetRv.getItems().add("Chirurgien");
        cboObjetRv.getItems().add("Pédiatre");
        cboObjetRv.getItems().add("Medecin Géneraliste");
        //cboObjetRv.getSelectionModel().selectFirst();
        //cboObjetRv.getSelectionModel().selectNext();

    }

    public static void loadComboBoxObjetPrestation(ComboBox<String> cboObjetRv) {
        //cboObjetRv.setItems(null);
        cboObjetRv.getItems().clear();
        cboObjetRv.getItems().add("Radio");
        cboObjetRv.getItems().add("Analyse");
        //cboObjetRv.getSelectionModel().selectFirst();
    }

    public static void loadComboBoxIdMedecin(ComboBox<Integer> cboIdMedecin) {
        //cboObjetRv.setItems(null);
        cboIdMedecin.getItems().clear();
        cboIdMedecin.getItems().add(1);
        cboIdMedecin.getItems().add(2);
        cboIdMedecin.getItems().add(3);
        cboIdMedecin.getItems().add(4);
        cboIdMedecin.getItems().add(5);
        //cboObjetRv.getSelectionModel().selectFirst();
    }

    public static void loadComboBoxValue(ComboBox<Integer> cboValue) {
        cboValue.getItems().add(0);
        cboValue.getSelectionModel().selectFirst();
    }

}
