/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.ConsultationDao;
import dao.MedecinDao;
import dao.PatientDao;
import dao.PrestationDao;
import dao.RendezVousDao;
import dao.SecretaireDao;
import dao.UserDao;
import entities.Consultation;
import entities.DossierMedical;
import entities.Medecin;
import entities.Patient;
import entities.RendezVous;
import entities.User;
import java.util.List;

/**
 *
 * @author ASUS
 */
public class Service implements IService {

    ConsultationDao daoConsultation = new ConsultationDao();
    PrestationDao daoPrestation = new PrestationDao();
    RendezVousDao daoRendezVous = new RendezVousDao();
    SecretaireDao daoSecretaire = new SecretaireDao();
    PatientDao daoPatient = new PatientDao();
    MedecinDao daoMedecin = new MedecinDao();
    UserDao daoUser = new UserDao();

    @Override
    public int planRendezVous(RendezVous rendezvous) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RendezVous> searchAllConsultationByPatient(int id) {
        return daoRendezVous.findAllConsultationByPatient(id);
    }

    @Override
    public List<RendezVous> searchAllPrestationByPatient(int id) {
        return daoRendezVous.findAllPrestationByPatient(id);
    }

    @Override
    public List<DossierMedical> searchDossierMedical(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public User login(String login, String password) {
        return daoUser.findUserLoginAndPassword(login, password);
    }

    @Override
    public int addPatient(Patient patient) {
        if (patient.getId() == 0) {
            int id = daoPatient.insert(patient);
            patient.setId(id);
        }
        Patient pat = new Patient();
        return patient.getId();
    }

    @Override
    public int addRendezVous(RendezVous rendezvous) {
        return daoRendezVous.insert(rendezvous);
    }

    @Override
    public boolean deleteRendezVous(int id) {
        return daoRendezVous.delete(id) != 0;
    }

    /*
    @Override
    public boolean deleteConsultation(int id) {
        return daoRendezVous.delete(id) != 0;
    }
     */
    @Override
    public boolean valideRendezVous(RendezVous rendezvous, int idMedecin) {
        return daoSecretaire.valideRendezVous(rendezvous, idMedecin) != 0;
    }

    @Override
    public List<RendezVous> searchAllConsultation() {
        return daoRendezVous.findAllConsultation();
    }

    @Override
    public List<RendezVous> searchAllPrestation() {
        return daoRendezVous.findAllPrestation();
    }

    @Override
    public List<Medecin> searchAllMedecin() {
        return daoMedecin.findAll();
    }

    @Override
    public List<RendezVous> searchAllConsultationByMedecin(int id) {
        return daoRendezVous.findAllRendezVousValide(id);
    }

    @Override
    public boolean doConsultation(Consultation consultation) {
       return daoConsultation.insert(consultation) != 0;
    }

    @Override
    public List<RendezVous> searchAllPrestationByMedecin(int id) {
         return daoPrestation.findAllRendezVousValide(id);
    }

}
