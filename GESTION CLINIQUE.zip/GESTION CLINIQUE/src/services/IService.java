/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Consultation;
import entities.DossierMedical;
import entities.Medecin;
import entities.Patient;
import entities.RendezVous;
import entities.User;
import java.util.List;

/**
 *
 * @author ASUS
 */
public interface IService {

//Patient
    public List<RendezVous> searchAllConsultationByPatient(int id);

    public List<RendezVous> searchAllPrestationByPatient(int id);

    public int addRendezVous(RendezVous rendezvous);

    public boolean deleteRendezVous(int id);

    public int addPatient(Patient patient);
    
//Secretaire  
    public boolean valideRendezVous(RendezVous rendezvous, int idMedecin);

    public List<RendezVous> searchAllConsultation();

    public List<RendezVous> searchAllPrestation();

    public List<Medecin> searchAllMedecin();

//Medecin   
    public List<RendezVous> searchAllConsultationByMedecin(int id);
    
    public List<RendezVous> searchAllPrestationByMedecin(int id);
    
    public List<DossierMedical> searchDossierMedical(int id);

    public int planRendezVous(RendezVous rendezvous);
    
    public boolean doConsultation(Consultation consultation);

//Se connecter 
    public User login(String login, String password);

}
