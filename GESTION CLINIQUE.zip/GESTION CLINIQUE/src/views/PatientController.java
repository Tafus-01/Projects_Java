/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class PatientController implements Initializable {

    @FXML
    private AnchorPane anchorContent;

    private static PatientController ctrl;
    @FXML
    private Text txtWelcome;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        txtWelcome.setText(ConnexionController.getCtrl().getUser().getPrenom()
                + " " + ConnexionController.getCtrl().getUser().getNom());

        try {
            loadView("v_rendezvous");
        } catch (IOException ex) {
            Logger.getLogger(PatientController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void loadView(String view) throws IOException {
        AnchorPane root;
        root = FXMLLoader.load(getClass().getResource("/views/" + view + ".fxml"));
        anchorContent.getChildren().clear();
        anchorContent.getChildren().add(root);
    }

    @FXML
    private void handleLoadViewRendezVous(ActionEvent event) throws IOException {
        loadView("v_rendezvous");

    }

    @FXML
    private void handleLoadViewConsultation(ActionEvent event) throws IOException {
        loadView("v_consultation");
    }

    @FXML
    private void handleLoadViewPrestation(ActionEvent event) throws IOException {
        loadView("v_prestation");
    }

    @FXML
    private void handleLoadViewConnexion(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Deconnexion");
        alert.setContentText("Voulez allez être déconnecter appuyer sur OK pour continuer");
        Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
        stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {
            this.anchorContent.getScene().getWindow().hide();
            AnchorPane root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/views/v_connexion.fxml"));
                Scene scene = new Scene(root);
                stage = new Stage();
                Image image = new Image("/images/first-aid-2789562_1280.png");
                stage.getIcons().add(image);
                stage.setTitle("Clinique 221");
                stage.setScene(scene);
                stage.show();
            } catch (IOException ex) {
                Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void getUserId() {
        System.out.println(ConnexionController.getCtrl().getUser().getId());
    }
}
