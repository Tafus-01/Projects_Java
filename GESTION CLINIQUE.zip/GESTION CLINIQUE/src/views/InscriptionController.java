/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import Utils.Validator;
import entities.DossierMedical;
import entities.Patient;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import services.Service;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class InscriptionController implements Initializable, IController {

 
    private Patient patient;
    Service service = new Service();

    @FXML
    private TextField txtfPrenom;
    @FXML
    private TextField txtfNom;
    @FXML
    private TextField txtfEmail;
    @FXML
    private PasswordField txtfPassword;
    @FXML
    private PasswordField txtfPasswordConfirmation;
    @FXML
    private TextField txtfPasseMedicaux;
    @FXML
    private Text txtError;
    @FXML
    private TextField txtfNci;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        txtError.setVisible(false);
    }

    @FXML
    private void handleInscription(ActionEvent event) {
        //valider les champs

        String nci = txtfNci.getText().trim();
        String prenom = txtfPrenom.getText().trim();
        String nom = txtfNom.getText().trim();
        String login = txtfEmail.getText().trim();
        String password = txtfPassword.getText().trim();
        String passwordConfirmation = txtfPasswordConfirmation.getText().trim();
        String passeMedicaux = txtfPasseMedicaux.getText().toUpperCase().trim();

        if (Validator.isValidNci(nci) && !nci.isEmpty() && Validator.isValidText(prenom) && !prenom.isEmpty()
                && Validator.isValidText(nom) && !nom.isEmpty() && Validator.isValidEmail(login) && !login.isEmpty()) {
            /*
            if (!nci.isEmpty() && !prenom.isEmpty() && !nom.isEmpty() && !login.isEmpty()
                    && !password.isEmpty() && !passwordConfirmation.isEmpty()
                    && !passeMedicaux.isEmpty()) {
             */
            if (password.equals(passwordConfirmation)) {
                patient = new Patient(passeMedicaux, nom, prenom, login, password, nci);
                service.addPatient(patient);

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Inscription");
                alert.setContentText("Inscription reussie ");
                Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
                stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
                alert.show();
                clearFields();
            } else {
                txtError.setText("* Le mot de passe doit etre identique");
                txtError.setVisible(true);
            }
            /*
            } else {
                txtError.setText("* Tous les champs doivent être remplies");
                txtError.setVisible(true);
            }
             */
        } else {
            txtError.setText("* Saisi incorrect ! Veuillez recommencer");
            txtError.setVisible(true);
        }

    }

    @FXML
    private void handleLienConnexion(ActionEvent event) {
        this.txtError.getScene().getWindow().hide();
        AnchorPane root;
        try {
            root = FXMLLoader.load(getClass().getResource("/views/v_connexion.fxml"));
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            Image image = new Image("/images/first-aid-2789562_1280.png");
            stage.getIcons().add(image);
            stage.setTitle("Clinique 221");
            stage.setScene(scene);
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void handleClear(ActionEvent event) {
        clearFields();
    }

    @Override
    public void clearFields() {
        txtfPrenom.clear();
        txtfNom.clear();
        txtfEmail.clear();
        txtfPassword.clear();
        txtfPasswordConfirmation.clear();
        txtfPasseMedicaux.clear();
        txtfNci.clear();
        txtError.setVisible(false);
    }

    @Override
    public void disableFields() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
