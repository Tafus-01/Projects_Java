/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import entities.RendezVous;
import java.net.URL;
import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import services.Service;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class ConsultationController implements Initializable {

    @FXML
    private TableView<RendezVous> tblvConsultation;
    @FXML
    private TableColumn<RendezVous, String> tblcId;
    @FXML
    private TableColumn<RendezVous, String> tblcDate;
    @FXML
    private TableColumn<RendezVous, String> tblcObjet;
    @FXML
    private TableColumn<RendezVous, String> tblcStatut;
    @FXML
    private TableColumn<RendezVous, String> tblcDateRv;
    @FXML
    private TableColumn<RendezVous, String> tblcHeureRv;
    @FXML
    private TextField txtfObjet;

    ObservableList<RendezVous> obvConsultation;

    private final Service service = new Service();

    private RendezVous rvSelected;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadTableView();
    }

    @FXML
    private void handleDelete(ActionEvent event) {

        if (txtfObjet.getText().trim().isEmpty()) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setContentText("Veuillez selectionner la Consultation à supprimer");
            Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
            stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
            alert.show();

        } else {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Consultation");
            alert.setContentText("Votre demande va être supprimée. Appuyer sur ok pour continuer");
            Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
            stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
            Optional<ButtonType> result = alert.showAndWait();

            if (result.get() == ButtonType.OK) {

                int periode = 0;

                if (rvSelected.getDateRv().equals("Vide") || Periode(periode) > 2) {

                    service.deleteRendezVous(rvSelected.getId());
                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Consultation");
                    alert.setContentText("Consultation supprimée avec succes");
                    stage = (Stage) alert.getDialogPane().getScene().getWindow();
                    stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
                    alert.show();
                    obvConsultation.remove(searchRendezVous(rvSelected));

                } else {

                    alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Erreur");
                    alert.setContentText("Votre rendez-vous arrive dans " + Periode(periode) + " jours. "
                            + "Impossible de le supprimer");
                    stage = (Stage) alert.getDialogPane().getScene().getWindow();
                    stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
                    alert.show();
                }

            }
            txtfObjet.clear();
        }

    }

    @FXML
    private void handleSelectConsultation(MouseEvent event) {
        rvSelected = tblvConsultation.getSelectionModel().getSelectedItem();
        txtfObjet.setText(rvSelected.getTypeDeRv().toUpperCase() + " : " + rvSelected.getObjetRv().toUpperCase());
    }

    public void loadTableView() {

        int id = ConnexionController.getCtrl().getUser().getId();
        List<RendezVous> consultations = service.searchAllConsultationByPatient(id);
        obvConsultation = FXCollections.observableArrayList(consultations);

        tblcId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tblcDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        tblcObjet.setCellValueFactory(new PropertyValueFactory<>("objetRv"));
        tblcStatut.setCellValueFactory(new PropertyValueFactory<>("statut"));
        tblcDateRv.setCellValueFactory(new PropertyValueFactory<>("dateRv"));
        tblcHeureRv.setCellValueFactory(new PropertyValueFactory<>("HeureRv"));

        tblvConsultation.setItems(obvConsultation);
    }

    private int searchRendezVous(RendezVous rendezvous) {

        int pos = -1;
        for (RendezVous rv : obvConsultation) {
            pos++;
            if (rendezvous.getId() == rv.getId()) {
                return pos;
            }
        }
        return pos;
    }

    private int Periode(int periode) {

        LocalDate dateDemande = LocalDate.parse(rvSelected.getDate().trim());
        LocalDate dateRv = LocalDate.parse(rvSelected.getDateRv().trim());
        return periode = Period.between(dateDemande, dateRv).getDays();
    }

}
