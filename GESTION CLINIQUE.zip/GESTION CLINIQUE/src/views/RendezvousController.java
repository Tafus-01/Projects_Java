/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import Utils.ViewService;
import static Utils.ViewService.loadComboBoxObjetConsultation;
import static Utils.ViewService.loadComboBoxObjetPrestation;
import entities.RendezVous;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import services.Service;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class RendezvousController implements Initializable, IController {

    @FXML
    private ComboBox<String> cboTypeRv;
    @FXML
    private ComboBox<String> cboObjetRv;
    @FXML
    private Label txtObjet;
    @FXML
    private Text txtError;

    private final Service service = new Service();

    private RendezVous rendezvous;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        ViewService.loadComboBoxTypeRv(cboTypeRv);
        txtError.setVisible(false);
    }

    @FXML
    private void handleAjouterRendezVous(ActionEvent event) {

        if (!cboTypeRv.getSelectionModel().isEmpty() && !cboObjetRv.getSelectionModel().isEmpty()) {

            int idPatient = ConnexionController.getCtrl().getUser().getId();
            String prenom = ConnexionController.getCtrl().getUser().getPrenom();
            String nom = ConnexionController.getCtrl().getUser().getNom();
            String typeRv = cboTypeRv.getSelectionModel().getSelectedItem();
            String objetRv = cboObjetRv.getSelectionModel().getSelectedItem();

            //System.out.println(ConnexionController.getCtrl().getUser().getNom());
            rendezvous = new RendezVous(idPatient, prenom, nom, typeRv, objetRv);
            service.addRendezVous(rendezvous);

            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Demande Rendez-Vous");
            alert.setContentText("Votre demande a été enregistrée avec succés");
            Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
            stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));

            alert.show();
            clearFields();

        } else {
            txtError.setText("*Choix incorrect");
            txtError.setVisible(true);
        }

    }

    @FXML
    private void handleTypeRv(ActionEvent event) {

        if (cboTypeRv.getSelectionModel().getSelectedItem().equals("Consultation")) {
            txtObjet.setText("Je souhaite voir un");
            loadComboBoxObjetConsultation(cboObjetRv);

        } else if (cboTypeRv.getSelectionModel().getSelectedItem().equals("Prestation")) {
            txtObjet.setText("Je souhaite faire une");
            loadComboBoxObjetPrestation(cboObjetRv);
        }
    }

    @FXML
    private void handleClear(ActionEvent event) {
        clearFields();
    }

    @Override
    public void clearFields() {
        txtError.setVisible(false);
    }

    @Override
    public void disableFields() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
