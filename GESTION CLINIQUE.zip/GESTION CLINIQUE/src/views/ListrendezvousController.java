/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import entities.RendezVous;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import services.Service;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class ListrendezvousController implements Initializable, IController {

    @FXML
    private TableView<RendezVous> tblvRv;
    @FXML
    private TableColumn<RendezVous, String> tblcId;
    @FXML
    private TableColumn<RendezVous, String> tblcNom;
    @FXML
    private TableColumn<RendezVous, String> tblcPrenom;
    @FXML
    private TableColumn<RendezVous, String> tblcTypeDeRv;
    @FXML
    private TableColumn<RendezVous, String> tblcObjetRv;
    @FXML
    private TableColumn<RendezVous, String> tblcDateRv;
    @FXML
    private TableColumn<RendezVous, String> tblcHeureRv;

    ObservableList<RendezVous> obvValideRv;

    private final Service service = new Service();

    private RendezVous rvSelected;
    @FXML
    private TextField txtfTypeRv;
    @FXML
    private TextField txtfNomComplet;
    @FXML
    private TextField txtfObjetRv;
    @FXML
    private TextField txtfDate;
    @FXML
    private FontAwesomeIcon filteredField;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        loadTableView();
        filteredByDate();

    }

    @FXML
    private void handleRvSelected(MouseEvent event) {
        rvSelected = tblvRv.getSelectionModel().getSelectedItem();
        txtfDate.setText(rvSelected.getDateRv());
        txtfNomComplet.setText(rvSelected.getPrenomPatient() + "  " + rvSelected.getNomPatient());
        txtfTypeRv.setText(rvSelected.getTypeDeRv());
        txtfObjetRv.setText(rvSelected.getObjetRv());
        disableFields();
    }

    @Override
    public void clearFields() {
        txtfNomComplet.clear();
        txtfTypeRv.clear();
        txtfObjetRv.clear();
    }

    @Override
    public void disableFields() {
        //dpDate.setDisable(true);
        txtfNomComplet.setDisable(true);
        txtfTypeRv.setDisable(true);
        txtfObjetRv.setDisable(true);
    }

    public void loadTableView() {
        int id = ConnexionController.getCtrl().getUser().getId();
        List<RendezVous> consultation = service.searchAllConsultationByMedecin(id);
        obvValideRv = FXCollections.observableArrayList(consultation);
        //Construction des colonnes
        tblcId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tblcPrenom.setCellValueFactory(new PropertyValueFactory<>("prenomPatient"));
        tblcNom.setCellValueFactory(new PropertyValueFactory<>("nomPatient"));
        tblcTypeDeRv.setCellValueFactory(new PropertyValueFactory<>("typeDeRv"));
        tblcObjetRv.setCellValueFactory(new PropertyValueFactory<>("objetRv"));
        tblcDateRv.setCellValueFactory(new PropertyValueFactory<>("dateRv"));
        tblcHeureRv.setCellValueFactory(new PropertyValueFactory<>("heureRv"));

        tblvRv.setItems(obvValideRv);
        //tblvRv.getItems().clear();
    }

    @FXML
    private void handleAnnuler(ActionEvent event) {
        if (txtfNomComplet.getText().trim().isEmpty()) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Validation");
            alert.setContentText("Veuillez selectionner le rendez-vous a Supprimer");
            Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
            stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
            alert.show();

        } else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Consultation");
            alert.setContentText("Appuyer sur OK pour confirmer la suppression");
            Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
            stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
            Optional<ButtonType> result = alert.showAndWait();

            if (result.get() == ButtonType.OK) {
                service.deleteRendezVous(rvSelected.getId());
                alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Supprimer");
                alert.setContentText("RendezVous supprimee avec succes");
                stage = (Stage) alert.getDialogPane().getScene().getWindow();
                stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
                alert.show();
                //loadTableView();
                obvValideRv.remove(searchRendezVous(rvSelected));

            }
            clearFields();

        }
    }

    @FXML
    private void handleSearchRvByDate(MouseEvent event) {

    }

    private void filteredByDate() {

        FilteredList<RendezVous> filteredData = new FilteredList<>(obvValideRv, b -> true);
        txtfDate.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(rendezvous -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();
                return -1 != String.valueOf(rendezvous.getDateRv()).indexOf(lowerCaseFilter);
            });
        });
        SortedList<RendezVous> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(tblvRv.comparatorProperty());
        tblvRv.setItems(sortedData);

    }

    private int searchRendezVous(RendezVous rendezvous) {
        int pos = -1;
        for (RendezVous rv : obvValideRv) {
            pos++;
            if (rendezvous.getId() == rv.getId()) {
                return pos;
            }
        }
        return pos;
    }

}
