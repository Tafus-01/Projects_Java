/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import Utils.ViewService;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTimePicker;
import entities.Consultation;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import services.Service;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class DoconsultationController implements Initializable {

    @FXML
    private ComboBox<Integer> cboTension;
    @FXML
    private ComboBox<Integer> cboTemperature;
    @FXML
    private TextField txtfPrenom;
    @FXML
    private TextField txtfNom;
    @FXML
    private JFXTimePicker tpHeure;
    @FXML
    private JFXDatePicker dpDate;

    private final Service service = new Service();

    private Consultation consultation;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        loadComboBoxValue();
    }

    @FXML
    private void handleValideConsultation(ActionEvent event) {

        if (txtfPrenom.getText().trim().isEmpty() || txtfNom.getText().trim().isEmpty()) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Validation");
            alert.setContentText("Veuillez renseigner toutes les informations");
            Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
            stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
            alert.show();

        } else {
            LocalDate myDate = dpDate.getValue();
            String date = myDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
            LocalTime myTime = tpHeure.getValue();
            String time = myTime.format(DateTimeFormatter.ofPattern("HH:mm"));
            int tension = cboTension.getSelectionModel().getSelectedItem();
            int temperature = cboTemperature.getSelectionModel().getSelectedItem();
            int idMedecin = ConnexionController.getCtrl().getUser().getId();
            int ipPatient = cboTension.getSelectionModel().getSelectedItem();

            consultation.setDate(date);
            consultation.setHeureRv(time);
            consultation.setTension(tension);
            consultation.setTemperature(temperature);
            consultation.setIdMedecin(idMedecin);
            consultation.setIdPatient(ipPatient);

            if (service.doConsultation(consultation)) {

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Validation");
                alert.setContentText("Rendez-vous validé avec succes");
                Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
                stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
                alert.show();
                //obvConsultation.set(searchRendezVous(rvSelected), rvSelected);
                //obvConsultation.remove(rvSelected);
            }
        }
    }

    public void loadComboBoxValue() {

        ViewService.loadComboBoxValue(cboTension);
        ViewService.loadComboBoxValue(cboTemperature);
        if (cboTension.getSelectionModel().getSelectedItem() == 0) {

            for (int i = 1; i < 101; i++) {
                cboTension.getItems().add(i);
                cboTemperature.getItems().add(i);
            }
        }
    }
}
