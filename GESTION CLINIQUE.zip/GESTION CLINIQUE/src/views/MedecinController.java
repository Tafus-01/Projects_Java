/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class MedecinController implements Initializable {

    @FXML
    private AnchorPane anchorContent;
    @FXML
    private Text txtWelcome;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        txtWelcome.setText("Docteur " + ConnexionController.getCtrl().getUser().getPrenom() + " "
                + ConnexionController.getCtrl().getUser().getNom());

        try {
            loadView("v_listrendezvous");
        } catch (IOException ex) {
            Logger.getLogger(MedecinController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void loadView(String view) throws IOException {
        AnchorPane root;
        root = FXMLLoader.load(getClass().getResource("/views/" + view + ".fxml"));
        anchorContent.getChildren().clear();
        anchorContent.getChildren().add(root);
    }

    @FXML
    private void handleLoadViewDossierMedical(ActionEvent event) throws IOException {
        loadView("v_dossiermedical");
    }

    @FXML
    private void handleLoadViewShowRv(ActionEvent event) throws IOException {
        loadView("v_listrendezvous");
    }

    @FXML
    private void handleLoadViewPlanRv(ActionEvent event) throws IOException {
        loadView("v_planrendezvous");
    }

    @FXML
    private void handleLoadViewConsultation(ActionEvent event) throws IOException {
        loadView("v_doconsultation");
    }

    @FXML
    private void handleLoadViewConnexion(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Deconnexion");
        alert.setContentText("Voulez allez être déconnecter appuyer sur OK pour continuer");
        Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
        stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {
            this.anchorContent.getScene().getWindow().hide();
            AnchorPane root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/views/v_connexion.fxml"));
                Scene scene = new Scene(root);
                stage = new Stage();
                Image image = new Image("/images/first-aid-2789562_1280.png");
                stage.getIcons().add(image);
                stage.setTitle("Clinique 221");
                stage.setScene(scene);
                stage.show();
            } catch (IOException ex) {
                Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
