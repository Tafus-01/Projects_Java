/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import Utils.ViewService;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTimePicker;
import entities.RendezVous;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import services.Service;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class ValideconsultationController implements Initializable {

    @FXML
    private TextField txtfObjet;
    @FXML
    private ComboBox<Integer> cboIdMedecin;
    @FXML
    private JFXDatePicker dpRv;
    @FXML
    private JFXTimePicker tpRv;
    @FXML
    private TableView<RendezVous> tblvConsultation;
    @FXML
    private TableColumn<RendezVous, String> tblcId;
    @FXML
    private TableColumn<RendezVous, String> tblcDateDemande;
    @FXML
    private TableColumn<RendezVous, String> tblcPrenomPatient;
    @FXML
    private TableColumn<RendezVous, String> tblcNomPatient;
    @FXML
    private TableColumn<RendezVous, String> tblcObjetRv;
    @FXML
    private TableColumn<RendezVous, String> tblcStatut;

    ObservableList<RendezVous> obvConsultation;

    private final Service service = new Service();

    private RendezVous rvSelected;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //txtfObjet.setDisable(true);
        ViewService.loadComboBoxIdMedecin(cboIdMedecin);
        loadTableView();
    }

    @FXML
    private void handleValiderConsultation(ActionEvent event) {

        if (txtfObjet.getText().trim().isEmpty()) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Validation");
            alert.setContentText("Veuillez selectionner le rendez-vous a valider");
            Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
            stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
            alert.show();

        } else {

            int idMedecin = cboIdMedecin.getSelectionModel().getSelectedItem();
            LocalDate myDate = dpRv.getValue();
            String dateRv = myDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            LocalTime myTime = tpRv.getValue();
            String timeRv = myTime.format(DateTimeFormatter.ofPattern("HH:mm"));

            rvSelected.setDateRv(dateRv);
            rvSelected.setHeureRv(timeRv);

            if (service.valideRendezVous((rvSelected), idMedecin)) {

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Validation");
                alert.setContentText("Rendez-vous validé avec succes");
                Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
                stage.getIcons().add(new Image(this.getClass().getResource("/images/first-aid-2789562_1280.png").toString()));
                alert.show();
                obvConsultation.set(searchRendezVous(rvSelected), rvSelected);
                //obvConsultation.remove(rvSelected);
            }
        }
        txtfObjet.clear();
    }

    @FXML
    private void handleSelectedConsultation(MouseEvent event) {

        rvSelected = tblvConsultation.getSelectionModel().getSelectedItem();
        txtfObjet.setText(rvSelected.getTypeDeRv().toUpperCase() + " : " + rvSelected.getObjetRv().toUpperCase());

    }

    public void loadTableView() {
        List<RendezVous> consultations = service.searchAllConsultation();
        obvConsultation = FXCollections.observableArrayList(consultations);
        //Construction des colonnes
        tblcId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tblcDateDemande.setCellValueFactory(new PropertyValueFactory<>("date"));
        tblcPrenomPatient.setCellValueFactory(new PropertyValueFactory<>("prenomPatient"));
        tblcNomPatient.setCellValueFactory(new PropertyValueFactory<>("nomPatient"));
        tblcObjetRv.setCellValueFactory(new PropertyValueFactory<>("objetRv"));
        tblcStatut.setCellValueFactory(new PropertyValueFactory<>("statut"));
        tblvConsultation.setItems(obvConsultation);
    }

    private int searchRendezVous(RendezVous rendezvous) {
        int pos = -1;
        for (RendezVous rv : obvConsultation) {
            pos++;
            if (rendezvous.getId() == rv.getId()) {
                return pos;
            }
        }
        return pos;
    }

}
