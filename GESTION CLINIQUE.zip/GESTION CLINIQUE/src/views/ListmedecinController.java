/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import entities.Medecin;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import services.Service;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class ListmedecinController implements Initializable {
    
    @FXML
    private TableView<Medecin> tblvListMedecin;
    @FXML
    private TableColumn<Medecin, String> tblcId;
    @FXML
    private TableColumn<Medecin, String> tblcPrenom;
    @FXML
    private TableColumn<Medecin, String> tblcNom;
    @FXML
    private TableColumn<Medecin, String> tblcTypeMedecin;
    @FXML
    private TableColumn<Medecin, String> tblcWorkDay;

    ObservableList<Medecin> obvMedecin;
    
    private final Service service = new Service();
    
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadTableView();
    }    

    @FXML
    private void handleSelectedMedecin(MouseEvent event) {
    }
    
    public void loadTableView() {
        List<Medecin> medecins = service.searchAllMedecin();
        obvMedecin = FXCollections.observableArrayList(medecins);
        //Construction des colonnes
        tblcId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tblcNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        tblcPrenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        tblcTypeMedecin.setCellValueFactory(new PropertyValueFactory<>("typeMedecin"));
        tblcWorkDay.setCellValueFactory(new PropertyValueFactory<>("workDay"));

        tblvListMedecin.setItems(obvMedecin);
    }

    /*
    private int searchMedein(Medecin medecin) {
        int pos = -1;
        for (Medecin md : obvMedecin) {
            pos++;
            if (medecin.getId() == md.getId()) {
                return pos;
            }
        }
        return pos;
    }
    */
}
